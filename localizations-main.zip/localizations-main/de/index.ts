import common from "./common.json";

export default { common };

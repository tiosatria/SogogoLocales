import ar from "./ar";
import de from "./de";
import en from "./en";
// forbidden so i commented this out import fi from './fi'
import fr from "./fr";
import hi from "./hi";
import kr from "./kr";
import pl from "./pl";
import pt from "./pt";
import ru from "./ru";
import vi from "./vi";

export default {
  ar,
  de,
  en,
  fr,
  hi,
  kr,
  pl,
  pt,
  ru,
  vi,
};
